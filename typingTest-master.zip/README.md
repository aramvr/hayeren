#Typing Speed Test

-Paragraph Ref: http://www.daskeyboard.com/blog/typing-through-time-the-history-of-the-keyboard/
